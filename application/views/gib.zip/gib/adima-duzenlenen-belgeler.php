<!DOCTYPE html>
<html lang="tr" xmlns="http://www.w3.org/1999/html">
<head>
	<?php $this->load->view("include/head-tags"); ?>

	<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/c3-chart/c3.min.css">

	<script src="https://www.amcharts.com/lib/4/core.js"></script>
	<script src="https://www.amcharts.com/lib/4/charts.js"></script>
	<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>

</head>
<body>

<?php $ses = session("r", "auth");
echo $ses; ?>


<!-- Main Wrapper -->
<div class="main-wrapper">

	<!-- Header -->
	<?php $this->load->view("include/header"); ?>
	<!-- /Header -->

	<!-- Sidebar -->
	<?php $this->load->view("include/sidebar"); ?>
	<!-- /Sidebar -->


	<!-- Page Wrapper -->
	<div class="page-wrapper">
		<div class="content container-fluid " style="padding-top:10px;">
			<div class="page-header">
				<div class="row">
					<div class="col-sm-10">
						<h3 class="page-title">Gib</h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?= base_url(); ?>">Anasayfa</a></li>
							<li class="breadcrumb-item">Gib</li>
							<li class="breadcrumb-item active">Adıma Düzenlenen Belgeler</li>
						</ul>
					</div>
					<div class="d-flex justify-content-end text-align-center col-sm-2">
						<a class="btn btn-outline-light" href="javascript:history.back()"><i class="fa fa-history"></i>
							<br>Önceki Sayfa</a>
					</div>
				</div>
			</div>
			<div id="newRow"></div>

			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">

							<form action="<?= base_url("gib/adimaDuzenlenenBelgeler") ?>" method="post">
								<div class="row">
									<div class="col-md-3">
										<input class="form-control" id="daterange" type="text" name="tarihAraligi" autocomplete="off"/>
									</div>
									<div class="col-md-2">
										<input type="submit" value="Sorgula" class="btn btn-danger">
									</div>
								</div>

							</form>
							<div class="table-responsive mt-4">
								<table class="table table-striped custom-table mb-0">
									<thead>
									<th>Tarih</th>
									<th>Belge Türü</th>
									<th>Belge Numarası</th>
									<th>Alıcı VKN/TCKN</th>
									<th>Alıcı Unvan</th>
									<th>Onay Durumu</th>
									<th>İptal/İtiraz Durumu</th>
									</thead>
									<tbody>
									<?php
										foreach ($invoice["data"] as $item)
										{?>
											<td><?= $item["belgeTarihi"] ?></td>
											<td><?= $item["belgeTuru"] ?></td>
											<td><?= $item["belgeNumarasi"] ?></td>
											<td><?= $item["saticiVknTckn"] ?></td>
											<td><?= $item["saticiUnvanAdSoyad"] ?></td>
											<td><?= $item["onayDurumu"] ?></td>
											<td><?php if(!$item["iptalItiraz"]) echo "----"; /* if($item["iptalItiraz"]==0) echo "İptal Kabul Edildi";else echo "İptal Kabul Edilmedi";*/ ?></td>
										<?php } ?>

									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>


		</div>
	</div>
	<!-- /Page Wrapper -->

</div>
<!-- /Main Wrapper -->

<?php $this->load->view("include/footer-js"); ?>

<script>
	$(function () {
		moment.locale('tr');
		$('#daterange').daterangepicker({
			opens: 'right',
			autoUpdateInput: false
		}, function (start, end, label) {
			$('#daterange').val(start.format('DD-MM-YYYY') + ' & ' + end.format('DD-MM-YYYY'));
			//console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
		});
		/*$('#daterange2').daterangepicker({
			opens: 'left',
			autoUpdateInput: false
		}, function (start, end, label) {
			$('#daterange2').val(start.format('DD.MM.YYYY') + ' - ' + end.format('DD.MM.YYYY'));
			//console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
		});*/
	});
</script>
</body>

</html>
