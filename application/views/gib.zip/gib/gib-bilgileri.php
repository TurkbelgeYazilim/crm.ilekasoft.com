<!DOCTYPE html>
<html lang="tr" xmlns="http://www.w3.org/1999/html">
<head>
	<?php $this->load->view("include/head-tags"); ?>

	<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/c3-chart/c3.min.css">

	<script src="https://www.amcharts.com/lib/4/core.js"></script>
	<script src="https://www.amcharts.com/lib/4/charts.js"></script>
	<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>

</head>
<body>

<?php $ses = session("r", "auth");
echo $ses; ?>


<!-- Main Wrapper -->
<div class="main-wrapper">

	<!-- Header -->
	<?php $this->load->view("include/header"); ?>
	<!-- /Header -->

	<!-- Sidebar -->
	<?php $this->load->view("include/sidebar"); ?>
	<!-- /Sidebar -->


	<!-- Page Wrapper -->
	<div class="page-wrapper">
		<div class="content container-fluid " style="padding-top:10px;">

			<div class="page-header">
				<div class="row">
					<div class="col-sm-10">
						<h3 class="page-title">Gib</h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?= base_url(); ?>">Anasayfa</a></li>
							<li class="breadcrumb-item">Gib</li>
							<li class="breadcrumb-item active">Gib Bilgileri</li>
						</ul>
					</div>
					<div class="d-flex justify-content-end text-align-center col-sm-2">
						<a class="btn btn-outline-light" href="javascript:history.back()"><i class="fa fa-history"></i>
							<br>Önceki Sayfa</a>
					</div>
				</div>
			</div>
			<div id="newRow"></div>

			<?php
			$anaHesap = anaHesapBilgisi();
			$ayarlarQ = "SELECT * FROM ayarlar WHERE ayarlar_id = '$anaHesap' ";
			$ayarlarExe = $this->db->query($ayarlarQ)->row();
			?>

			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
<a href="<?= base_url("gib/guvenliCikis") ?>">Güvenli Çıkış</a>
							<form method="post" action="<?= base_url("gib/bilgiGuncelle") ?>">
								<div class="row">

									<div class="form-group col-3">
										<label>VKN/TCKN</label>
										<input type="text" name="taxIDOrTRID" value="<?= $data->vknTckn ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Vergi Dairesi</label>
										<input type="text" name="taxOffice" value="<?= $data->vergiDairesi ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Sicil Numarası</label>
										<input type="text" name="registryNo" value="<?= $data->sicilNo ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Mersis Numarası</label>
										<input type="text" name="mersisNo" value="<?= $data->mersisNo ?>"
											   class="form-control">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-3">
										<label>Ünvan</label>
										<input type="text" name="title" value="<?= $data->unvan ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Ad</label>
										<input type="text" name="name" value="<?= $data->ad ?>" class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Soyad</label>
										<input type="text" name="surname" value="<?= $data->soyad ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Ülke</label>
										<input type="text" name="country" value="<?= $data->ulke ?>"
											   class="form-control">
									</div>
								</div>

								<div class="row">

									<div class="form-group col-3">
										<label>İl</label>
										<input type="text" name="city" value="<?= $data->il ?>" class="form-control">
									</div>
									<div class="form-group col-3">
										<label>İlçe</label>
										<input type="text" name="district" value="<?= $data->ilce ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Cadde</label>
										<input type="text" name="cadde" value="<?= $data->cadde ?>"
											   class="form-control">
									</div>

									<div class="form-group col-3">
										<label>İş Merkezi</label>
										<input type="text" name="businessCenter" value="<?= $data->isMerkezi ?>"
											   class="form-control">
									</div>

								</div>
								<div class="row">

									<div class="form-group col-3">
										<label>Apartman Adı</label>
										<input type="text" name="buildingName" value="<?= $data->apartmanAdi ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Apartman Numarası</label>
										<input type="text" name="buildingNumber" value="<?= $data->apartmanNo ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Mahalle</label>
										<input type="text" name="town" value="<?= $data->kasaba ?>" class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Kapı Numarası</label>
										<input type="text" name="doorNumber" value="<?= $data->kapiNo ?>"
											   class="form-control">
									</div>


								</div>

								<div class="row">


									<div class="form-group col-3">
										<label>Posta Kodu</label>
										<input type="text" name="zipCode" value="<?= $data->postaKodu ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Telefon Numarası</label>
										<input type="text" name="phoneNumber" value="<?= $data->telNo ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>Fax Numarası</label>
										<input type="text" name="faxNumber" value="<?= $data->faxNo ?>"
											   class="form-control">
									</div>
									<div class="form-group col-3">
										<label>E-posta</label>
										<input type="text" name="email" value="<?= $data->ePostaAdresi ?>"
											   class="form-control">
									</div>
								</div>
								<div class="row">
									<div class="col-4">
										<input type="submit" class="btn btn-danger" value="Güncelle">
									</div>
								</div>


							</form>
						</div>

					</div>
				</div>
			</div>


		</div>
	</div>
	<!-- /Page Wrapper -->

</div>
<!-- /Main Wrapper -->

<?php $this->load->view("include/footer-js"); ?>

</body>

</html>
