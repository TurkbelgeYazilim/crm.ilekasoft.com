<!DOCTYPE html>
<html lang="tr">
<head>
	<?php $this->load->view("include/head-tags"); ?>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"
		  integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA=="
		  crossorigin="anonymous" referrerpolicy="no-referrer"/>

	<style>

		.form-group {
			margin-bottom: 10px !important;
		}

		.card {
		. margin-bottom: 0 px !important;
		}


		* {
			box-sizing: border-box;
		}

		.sr-only {
			visibility: hidden;
		}

		.hidden {
			width: 0;
			height: 0;
			visibility: hidden;
			display: none;
			overflow: hidden;
		}

		.challenge-title {
			text-align: center;
			padding: 0;
			margin: 1rem 0 0.5rem;
			color: blue;
			font-size: 2rem;
			font-weight: bold;
		}

		.challenge-subtitle {
			text-align: center;
			margin: 0;
			font-size: 1.125rem;
			font-weight: 400;
			color: yellow;
		}

		.challenge-part-of {
			text-align: center;
			margin: 1rem 0 0;
			font-size: 0.875rem;
			color:black;
			position: fixed;
			bottom: 1rem;
			right: 1rem;
		a,
		a:visited {
			color: red;
			text-decoration-style: wavy;
		}
		a:hover,
		a:active {
			 color: green;
		 }


		.container {
			margin: 1.5rem;
			padding: 2rem;
			width: 1000px;
			min-height: 300px;
			border: 1px solid $default;
			border-radius: 1rem;
		}

		.sbs-title {
			color: blue;
			text-transform: uppercase;
			font-size: 0.625rem;
			margin: 0 0 1rem;
			padding: 1rem 0;
		}
		.sbs-title:first-of-type {
			 padding-top: 0;
			 margin-top: 0;
		 }

		hr {
			border-top: 1px solid red;
			margin: 3rem 0 2rem;
		}

		.sbs--basic {
			margin: 0 -1rem;
			display: flex;
		li {
			flex: 1;
			padding: 0 1rem;

		li.finished > .step {
		li::before {
			 border-color:red;
		 }
		.title {
			color: blue;
		}
		}
		li.active > .step {
		li::before {
			 border-color:black;
			 border-top-style: dotted;
		 }
		.title {
			color: orange;
		}
		}
		.step {
			padding: 2rem 0 0;
			display: flex;
			flex-direction: column;
			position: relative;
		.step::before {
			 content: "";
			 position: absolute;
			 top: 0;
			 left: 0;
			 height: 0;
			 width: 100%;
			 border-top: 4px solid red;
		 }
		.title {
			margin-bottom: 0.5rem;
			text-transform: uppercase;
			font-size: 0.875rem;
			font-weight: bold;
			color: green;
		}
		.description {
			font-weight: bold;
		}
		}
		}
		}

		.sbs--border {
			display: flex;
			border: 1px solid $default;
			border-radius: 0.5rem;
		li {
			flex: 1;
		li:last-of-type {
		.step::before,
		.step::after {
			display: none;
		}
		}
		li.finished > .step {
		.indicator {
			background-color: blue;
			border-color: green;
			color: white;
		}
		.description {
			color: black;
		}
		}
		.description.active > .step {
		.indicator {
			border-color: black;
			color: green;
		}
		.description {
			color: red;
		}
		}
		.step {
			padding: 1rem 1.5rem;
			display: flex;
			align-items: center;
			position: relative;
		.step::before,
		.step::after {
			 content: "";
			 height: 45px;
			 width: 1px;
			 background-color: red;
			 position: absolute;
			 right: 0;
			 top: 50%;
		 }
		.step::before {
			 transform-origin: center bottom;
			 transform: translateY(-100%) rotate(-25deg);
		 }
		.step::after {
			 transform-origin: center top;
			 transform: rotate(25deg);
		 }
		.indicator {
			display: flex;
			align-items: center;
			justify-content: center;
			font-weight: bold;
			width: 3rem;
			height: 3rem;
			border-radius: 50%;
			margin-right: 1rem;
			border: 2px solid red;
			color: blue;
		}
		.description {
			font-weight: bold;
			font-size: 0.875rem;
			color: orange;
		}
		}
		}
		}

		.sbs--border-alt {
			display: flex;
			border: 1px solid black;
			border-radius: 0.5rem;
		li {
			flex: 1;
		li:last-of-type {
		.step::before,
		.step::after {
			display: none;
		}
		}
		li.finished > .step {
		.indicator {
			background-color: red;
			border-color:red;
			color: white;
		}
		.description {
			color: blue;
		}
		}
		li.active > .step {
		.indicator {
			border-color: black;
			color: black;
		}
		.description {
			color: black;
		}
		.line {
			background-color: black;
		}
		}
		.step {
			padding: 1rem 1.5rem;
			display: flex;
			align-items: center;
			position: relative;
		.step::before {
			 content: "";
			 width: 1px;
			 height: 100%;
			 background-color: black;
			 position: absolute;
			 right: 0;
		 }
		.step::after {
			 content: "";
			 width: 1rem;
			 height: 1rem;
			 background-color: white;
			 position: absolute;
			 right: 0;
			 top: 50%;
			 border-top: 1px solid black;
			 border-right: 1px solid black;
			 transform: translate(50%, -50%) rotate(45deg);
			 z-index: 1;
		 }
		.indicator {
			display: flex;
			align-items: center;
			justify-content: center;
			font-weight: bold;
			width: 3rem;
			height: 3rem;
			border-radius: 50%;
			margin-right: 1rem;
			border: 2px solid black;
			color: black;
		}
		.description {
			font-weight: bold;
			font-size: 0.875rem;
			color: black;
			display: flex;
			flex-direction: column;
		span {
		.description:first-of-type {
			 margin-bottom: 0.25rem;
			 text-transform: uppercase;
		 }
		.description:last-of-type {
			 color: black;
		 }
		}
		}
		.line {
			position: absolute;
			width: 100%;
			height: 4px;
			background-color: transparent;
			bottom: 0;
			left: 0;
		}
		}
		}
		}

		.sbs--circles {
			display: flex;
		li {
			flex: 1;
			display: flex;
			flex-direction: column;
		li:last-of-type {
		.step {
		.line {
			display: none;
		}
		}
		}
		li.finished > .step {
		.indicator {
			background-color: black;
			border-color: black;
			color: white;
		}
		.description {
			color: black;
		}
		.line {
			background-color:black;
		}
		}
		li.active > .step {
		.indicator {
			border-color: black;
			color: black;
		}
		.description {
			color:black;
		}
		}
		.step {
			display: flex;
			flex-direction: column;
			align-items: center;
			position: relative;
		.indicator {
			display: flex;
			align-items: center;
			justify-content: center;
			font-weight: bold;
			width: 3rem;
			height: 3rem;
			border-radius: 50%;
			border: 2px solid black;
			color:black;
			position: relative;
			z-index: 1;
			background-color: white;
		}
		.description {
			font-weight: bold;
			font-size: 0.875rem;
			color: black;
			position: absolute;
			bottom: -1.5rem;
		}
		.line {
			height: 4px;
			background-color: black;
			width: 100%;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translateY(-50%);
		}
		}
		}
		}

		.sbs--dots {
			display: flex;
			flex-direction: column;
			width: 200px;
			margin: 0 auto;
		li {
			padding: 1rem 0;
		li.finished > .step {
		.indicator {
			background-color:black;
			border-color: black;
			color: white;
		}
		.description {
			color: black;
		}
		.line {
			background-color: black;
		}
		}
		li.active > .step {
		.indicator {
			border-color: black;
			background-color: black;
		}
		.description {
			color: black;
		}
		}
		.step {
			display: flex;
			position: relative;

		.indicator {
			display: flex;
			align-items: center;
			justify-content: center;
			font-weight: bold;
			width: 1.125rem;
			height: 1.125rem;
			border-radius: 50%;
			border: 4px solid white;
			color:black;
			position: absolute;
			top: 50%;
			left: -2rem;
			transform: translateY(-50%);
			background-color: black;
			font-size: 0.625rem;
		}
		.description {
			font-weight: bold;
			font-size: 0.875rem;
			color: black;
		}
		}
		}
		}

		.sbs > li {
			cursor: pointer;
		li.active {
			 cursor: default;
		 }
		}


	</style>

	<script>
		var formatter = new Intl.NumberFormat('tr-TR');
		var items = 0;
		var counter = [];
		var paraBirimiMetin = "TL";
		var items_indirim = 0;
		var counter_indirim = [];
		var items_iade = 0;
		var counter_iade = [];
		var items_banka = 0;
		var counter_banka = [];
		var checkboxbanka = 0;
	</script>
</head>
<body>

<!-- Main Wrapper -->
<div class="main-wrapper">
	<!-- Header -->
	<?php $this->load->view("include/header"); ?>
	<!-- /Header -->

	<!-- Sidebar -->
	<?php $this->load->view("include/sidebar"); ?>
	<!-- /Sidebar -->

	<!-- Page Wrapper -->
	<div class="page-wrapper">
		<div class="content container-fluid">

			<!-- Page Header -->
			<div class="page-header">
				<div class="row">
					<div class="col-sm-10">
						<h3 class="page-title">Gib</h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?= base_url(); ?>">Anasayfa</a></li>
							<li class="breadcrumb-item">Gib</li>
							<li class="breadcrumb-item active">Fatura Oluştur</li>
						</ul>
					</div>
					<div class="d-flex justify-content-end text-align-center col-sm-2">
						<a class="btn btn-outline-light" href="javascript:history.back()"><i class="fa fa-history"></i>
							<br>Önceki Sayfa</a>
					</div>
				</div>
			</div>
			<!-- /Page Header -->

			<div id="newRow"></div>

			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
							<h1 class="challenge-title">Step-by-step</h1>
							<h2 class="challenge-subtitle">#28ComponentsOfFebruaryDay9</h2>
							<p class="challenge-part-of">Part of <a href="https://codepen.io/collection/DQRePJ" target="_blank">28 Components of February</a> collection.</p>

							<div class="container">
								<h3 class="sbs-title">Basic</h3>
								<ul class="sbs sbs--basic">
									<li class="finished">
										<div class="step">
											<span class="title">Step 1</span>
											<span class="description">Create Account</span>
										</div>
									</li>
									<li class="active">
										<div class="step">
											<span class="title">Step 2</span>
											<span class="description">Billing Information</span>
										</div>
									</li>
									<li>
										<div class="step">
											<span class="title">Step 3</span>
											<span class="description">Summary</span>
										</div>
									</li>
								</ul>
								<hr />
								<h3 class="sbs-title">Border</h3>
								<ul class="sbs sbs--border">
									<li class="finished">
										<div class="step">
											<span class="indicator" data-default="01"><i class="fa fa-check"></i></span>
											<span class="description">Create Account</span>
										</div>
									</li>
									<li class="active">
										<div class="step">
											<span class="indicator" data-default="02">02</span>
											<span class="description">Billing Information</span>
										</div>
									</li>
									<li>
										<div class="step">
											<span class="indicator" data-default="03">03</span>
											<span class="description">Summary</span>
										</div>
									</li>
								</ul>
								<hr />
								<h3 class="sbs-title">Border Alt</h3>
								<ul class="sbs sbs--border-alt">
									<li class="finished">
										<div class="step">
											<span class="indicator" data-default="01"><i class="fa fa-check"></i></span>
											<span class="description">
					<span>Create Account</span>
					<span>Just started...</span>
				</span>
											<span class="line"></span>
										</div>
									</li>
									<li class="active">
										<div class="step">
											<span class="indicator" data-default="02">02</span>
											<span class="description">
					<span>Billing Information</span>
					<span>Almost ready.</span>
				</span>
											<span class="line"></span>
										</div>
									</li>
									<li>
										<div class="step">
											<span class="indicator" data-default="03">03</span>
											<span class="description">
					<span>Summary</span>
					<span>Great! You are done.</span>
				</span>
											<span class="line"></span>
										</div>
									</li>
								</ul>
								<hr />
								<h3 class="sbs-title">Circles</h3>
								<ul class="sbs sbs--circles">
									<li class="finished">
										<div class="step">
											<span class="indicator"><i class="fa fa-check"></i></span>
											<span class="description">
					Create Account
				</span>
											<span class="line"></span>
										</div>
									</li>
									<li class="active">
										<div class="step">
											<span class="indicator"><i class="fa fa-circle"></i></span>
											<span class="description">
					Billing Information
				</span>
											<span class="line"></span>
										</div>
									</li>
									<li>
										<div class="step">
											<span class="indicator"></span>
											<span class="description">
					Summary
				</span>
											<span class="line"></span>
										</div>
									</li>
								</ul>
								<hr />
								<h3 class="sbs-title">Dots</h3>
								<ul class="sbs sbs--dots">
									<li class="finished">
										<div class="step">
											<span class="indicator"><i class="fa fa-check"></i></span>
											<span class="description">
					Create Account
				</span>
										</div>
									</li>
									<li class="active">
										<div class="step">
											<span class="indicator"></span>
											<span class="description">
					Billing Information
				</span>
										</div>
									</li>
									<li>
										<div class="step">
											<span class="indicator"></span>
											<span class="description">
					Summary
				</span>
										</div>
									</li>
								</ul>
							</div>

							<?php
							if($invoice)
								$action="gib/faturaDuzenleKaydet";
							else
								$action="gib/faturaOlusturKaydet";

							?>
							<form action="<?= base_url($action); ?>" method="POST" id="myForm">
								<input type="hidden" name="belgeNumarasi" value="<?=$invoice["belgeNumarasi"]?>">
								<input type="hidden" name="faturaUuid" value="<?=$invoice["faturaUuid"]?>">
								<div class="row">
									<div class="col-md-6">
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">TCKN/VKN </label>
												<div class="col-sm-8">
													<input type="text" class="form-control" name="tcknvkn"
														   id="tcknvkn" required=""
														   value="<?= $invoice["vknTckn"] ?>">
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Unvan </label>
												<div class="col-sm-8">
													<input type="text" class="form-control" name="unvan"
														   id="unvan" required
														   value="<?= $invoice["aliciUnvan"] ?>">
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Ad </label>
												<div class="col-sm-8">
													<input type="text" class="form-control" name="ad"
														   id="ad" required
														   value="<?= $invoice["aliciAdi"] ?>">
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Soyad </label>
												<div class="col-sm-8">
													<input type="text" class="form-control" name="soyad"
														   id="soyad" required
														   value="<?= $invoice["aliciSoyadi"] ?>">
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Vergi Dairesi </label>
												<div class="col-sm-8">
													<input type="text" class="form-control" name="vergiDairesi"
														   id="vergiDairesi"
														   value="<?= $invoice["vergiDairesi"] ?>">
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Ülke </label>
												<div class="col-sm-8">
													<select class="form-control" name="ulke" required>
														<option value="">-----</option>
														<option value="Türkiye" <?php if ($invoice) echo "selected"; ?>>
															Türkiye
														</option>
														<!--	<option value="Abd Minor Outlying A">Abd Minor Outlying A
															</option>
															<option value="Abd Virjin Adaları">Abd Virjin Adaları</option>
															<option value="Afganistan">Afganistan</option>
															<option value="Almanya">Almanya</option>
															<option value="Amerika Birleşik Dev">Amerika Birleşik Dev
															</option>
															<option value="Amerika Samoasi">Amerika Samoasi</option>
															<option value="Andorra">Andorra</option>
															<option value="Angola">Angola</option>
															<option value="Anguilla">Anguilla</option>
															<option value="Antartika">Antartika</option>
															<option value="Antigua Ve Bermuda">Antigua Ve Bermuda</option>
															<option value="Arjantin">Arjantin</option>
															<option value="Arnavutluk">Arnavutluk</option>
															<option value="Aruba">Aruba</option>
															<option value="Avustralya">Avustralya</option>
															<option value="Avustralya Okyanusu">Avustralya Okyanusu</option>
															<option value="Avusturya">Avusturya</option>
															<option value="Azerbeycan-Nahçivan">Azerbeycan-Nahçivan</option>
															<option value="Bahamalar">Bahamalar</option>
															<option value="Bahreyn">Bahreyn</option>
															<option value="Bangladeş">Bangladeş</option>
															<option value="Barbados">Barbados</option>
															<option value="Belçika">Belçika</option>
															<option value="Belize">Belize</option>
															<option value="Benin">Benin</option>
															<option value="Bermuda">Bermuda</option>
															<option value="Beyaz Rusya">Beyaz Rusya</option>
															<option value="Bhutan">Bhutan</option>
															<option value="Bolivya">Bolivya</option>
															<option value="Bosna-Hersek">Bosna-Hersek</option>
															<option value="Bostvana">Bostvana</option>
															<option value="Bouvet Adası">Bouvet Adası</option>
															<option value="Brezilya">Brezilya</option>
															<option value="Brunei">Brunei</option>
															<option value="Bulgaristan">Bulgaristan</option>
															<option value="Burkina Faso">Burkina Faso</option>
															<option value="Burma">Burma</option>
															<option value="Burundi">Burundi</option>
															<option value="Birleşik Arap Emirli">Birleşik Arap Emirli
															</option>
															<option value="Birleşik Devletler M">Birleşik Devletler M
															</option>
															<option value="Birleşik Krallik">Birleşik Krallik</option>
															<option value="Bismark Archipelago">Bismark Archipelago</option>
															<option value="Cape Verde">Cape Verde</option>
															<option value="Cayman Adaları">Cayman Adaları</option>
															<option value="Cebeli Tarik">Cebeli Tarik</option>
															<option value="Ceuta Ve Melilla">Ceuta Ve Melilla</option>
															<option value="Cezayir">Cezayir</option>
															<option value="Christmas Adaları">Christmas Adaları</option>
															<option value="Cook Adaları">Cook Adaları</option>
															<option value="Cibuti">Cibuti</option>
															<option value="Çad">Çad</option>
															<option value="Çek Cumhuriyeti">Çek Cumhuriyeti</option>
															<option value="Çeçen Cumhuriyeti">Çeçen Cumhuriyeti</option>
															<option value="Çin Halk Cumhuriyeti">Çin Halk Cumhuriyeti
															</option>
															<option value="Danimarka">Danimarka</option>
															<option value="Dağistan Cumhuriyeti">Dağistan Cumhuriyeti
															</option>
															<option value="Dominik Cumhuriyeti">Dominik Cumhuriyeti</option>
															<option value="Dominika">Dominika</option>
															<option value="Doğu Timor">Doğu Timor</option>
															<option value="Dubai">Dubai</option>
															<option value="Ekvator">Ekvator</option>
															<option value="Ekvator Ginesi">Ekvator Ginesi</option>
															<option value="El Salvador">El Salvador</option>
															<option value="Endonezya">Endonezya</option>
															<option value="Ermenistan">Ermenistan</option>
															<option value="Eritre">Eritre</option>
															<option value="Estonya">Estonya</option>
															<option value="Etiyopya">Etiyopya</option>
															<option value="Falkland Adaları">Falkland Adaları</option>
															<option value="Faroe Adaları">Faroe Adaları</option>
															<option value="Faroe Adaları">Faroe Adaları</option>
															<option value="Fas">Fas</option>
															<option value="Fransa">Fransa</option>
															<option value="Fransiz Guyanasi">Fransiz Guyanasi</option>
															<option value="Fransiz Güney Toprak">Fransiz Güney Toprak
															</option>
															<option value="Fransiz Polinezyasi">Fransiz Polinezyasi</option>
															<option value="Fiji">Fiji</option>
															<option value="Fildişi Sahili">Fildişi Sahili</option>
															<option value="Filipinler">Filipinler</option>
															<option value="Filistin">Filistin</option>
															<option value="Finlandiya">Finlandiya</option>
															<option value="Gabon">Gabon</option>
															<option value="Gambiya">Gambiya</option>
															<option value="Gana">Gana</option>
															<option value="Grenada">Grenada</option>
															<option value="Grönland">Grönland</option>
															<option value="Guadelup">Guadelup</option>
															<option value="Guam">Guam</option>
															<option value="Guatemala">Guatemala</option>
															<option value="Guyana">Guyana</option>
															<option value="Güney Afrika Cumhuri">Güney Afrika Cumhuri
															</option>
															<option value="Güney Fransiz Toprak">Güney Fransiz Toprak
															</option>
															<option value="Güney Georgia Ve Gün">Güney Georgia Ve Gün
															</option>
															<option value="Güney Kore Cumhuriye">Güney Kore Cumhuriye
															</option>
															<option value="Güney Yemen">Güney Yemen</option>
															<option value="Gürcistan">Gürcistan</option>
															<option value="Gine">Gine</option>
															<option value="Gine-Bissau">Gine-Bissau</option>
															<option value="Haiti">Haiti</option>
															<option value="Heard Adaları Ve Mc">Heard Adaları Ve Mc</option>
															<option value="Hirvatistan">Hirvatistan</option>
															<option value="Hollanda">Hollanda</option>
															<option value="Hollanda Antilleri">Hollanda Antilleri</option>
															<option value="Honduras">Honduras</option>
															<option value="Hong Kong">Hong Kong</option>
															<option value="Hindistan">Hindistan</option>
															<option value="Irak">Irak</option>
															<option value="İngiliz Hint Oky.Top">İngiliz Hint Oky.Top
															</option>
															<option value="İngiliz Virgin Adala">İngiliz Virgin Adala
															</option>
															<option value="İran">İran</option>
															<option value="İrlanda">İrlanda</option>
															<option value="İspanya">İspanya</option>
															<option value="İsrail">İsrail</option>
															<option value="İsveç">İsveç</option>
															<option value="İsviçre">İsviçre</option>
															<option value="İtalya">İtalya</option>
															<option value="İzlanda">İzlanda</option>
															<option value="İşgal Altindaki Fili">İşgal Altindaki Fili
															</option>
															<option value="Jamaika">Jamaika</option>
															<option value="Japonya">Japonya</option>
															<option value="Kamboçya">Kamboçya</option>
															<option value="Kamerun">Kamerun</option>
															<option value="Kanada">Kanada</option>
															<option value="Karadağ">Karadağ</option>
															<option value="Katar">Katar</option>
															<option value="Kazakistan">Kazakistan</option>
															<option value="Kenya">Kenya</option>
															<option value="Kibris Rum Kesimi">Kibris Rum Kesimi</option>
															<option value="Kirgizistan">Kirgizistan</option>
															<option value="Kokos Adaları">Kokos Adaları</option>
															<option value="Kolombiya">Kolombiya</option>
															<option value="Komoro Adaları">Komoro Adaları</option>
															<option value="Kongo">Kongo</option>
															<option value="Kosova">Kosova</option>
															<option value="Kosta Rika">Kosta Rika</option>
															<option value="Kutup Bölgeleri">Kutup Bölgeleri</option>
															<option value="Kuveyt">Kuveyt</option>
															<option value="Kuzey Kibris Türk Cu">Kuzey Kibris Türk Cu
															</option>
															<option value="Kuzey Kore Demokrati">Kuzey Kore Demokrati
															</option>
															<option value="Kuzey Mariana Adalar">Kuzey Mariana Adalar
															</option>
															<option value="Kuzey Yemen">Kuzey Yemen</option>
															<option value="Kongo (Demokratik Cu)">Kongo (Demokratik Cu)
															</option>
															<option value="Küba">Küba</option>
															<option value="Kiribati">Kiribati</option>
															<option value="Laos">Laos</option>
															<option value="Lesotho">Lesotho</option>
															<option value="Letonya">Letonya</option>
															<option value="Lieshtenstein">Lieshtenstein</option>
															<option value="Lübnan">Lübnan</option>
															<option value="Lüksemburg">Lüksemburg</option>
															<option value="Liberya">Liberya</option>
															<option value="Libya">Libya</option>
															<option value="Litvanya">Litvanya</option>
															<option value="Macaristan">Macaristan</option>
															<option value="Madagaskar">Madagaskar</option>
															<option value="Makao">Makao</option>
															<option value="Makedonya">Makedonya</option>
															<option value="Malavi">Malavi</option>
															<option value="Maldiv Adaları">Maldiv Adaları</option>
															<option value="Malezya">Malezya</option>
															<option value="Malta">Malta</option>
															<option value="Mali">Mali</option>
															<option value="Marshall Adaları">Marshall Adaları</option>
															<option value="Martinik">Martinik</option>
															<option value="Mauritius">Mauritius</option>
															<option value="Mayotte">Mayotte</option>
															<option value="Meksika">Meksika</option>
															<option value="Melilla">Melilla</option>
															<option value="Misir">Misir</option>
															<option value="Moldavya">Moldavya</option>
															<option value="Monaco">Monaco</option>
															<option value="Montserrat">Montserrat</option>
															<option value="Moritanya">Moritanya</option>
															<option value="Mozambik">Mozambik</option>
															<option value="Moğolistan">Moğolistan</option>
															<option value="Myanmar">Myanmar</option>
															<option value="Mikronezya">Mikronezya</option>
															<option value="Namibya">Namibya</option>
															<option value="Nauru">Nauru</option>
															<option value="Nepal">Nepal</option>
															<option value="Norfolk Adası">Norfolk Adası</option>
															<option value="Norveç">Norveç</option>
															<option value="Nijer">Nijer</option>
															<option value="Nijerya">Nijerya</option>
															<option value="Nikaragua">Nikaragua</option>
															<option value="Niue">Niue</option>
															<option value="Orta Afrika Cumhuriy">Orta Afrika Cumhuriy
															</option>
															<option value="Özbekistan">Özbekistan</option>
															<option value="Pakistan">Pakistan</option>
															<option value="Palau">Palau</option>
															<option value="Panama">Panama</option>
															<option value="Papua Yeni Gine">Papua Yeni Gine</option>
															<option value="Paraguay">Paraguay</option>
															<option value="Peru">Peru</option>
															<option value="Polonya">Polonya</option>
															<option value="Portekiz">Portekiz</option>
															<option value="Pitcairn">Pitcairn</option>
															<option value="Reunion">Reunion</option>
															<option value="Romanya">Romanya</option>
															<option value="Ruanda">Ruanda</option>
															<option value="Rusya Federasyonu">Rusya Federasyonu</option>
															<option value="San Marino">San Marino</option>
															<option value="Sao Tome And Princip">Sao Tome And Princip
															</option>
															<option value="Senegal">Senegal</option>
															<option value="Septe(Ceuta)">Septe(Ceuta)</option>
															<option value="Seyşel Adaları Ve Ba">Seyşel Adaları Ve Ba
															</option>
															<option value="Sierra Leone">Sierra Leone</option>
															<option value="Sirbistan">Sirbistan</option>
															<option value="Slovakya">Slovakya</option>
															<option value="Slovenya">Slovenya</option>
															<option value="Solomon Adaları">Solomon Adaları</option>
															<option value="Somali">Somali</option>
															<option value="Sri Lanka">Sri Lanka</option>
															<option value="St Vincent Ve Grenad">St Vincent Ve Grenad
															</option>
															<option value="St. Helena Ve Bağlan">St. Helena Ve Bağlan
															</option>
															<option value="St. Kitts Ve Nevis">St. Kitts Ve Nevis</option>
															<option value="St. Lucia">St. Lucia</option>
															<option value="St. Pierre Ve Miquel">St. Pierre Ve Miquel
															</option>
															<option value="Sudan">Sudan</option>
															<option value="Surinam">Surinam</option>
															<option value="Suriye">Suriye</option>
															<option value="Suudi Arabistan">Suudi Arabistan</option>
															<option value="Svaziland">Svaziland</option>
															<option value="Samoa (Batı Samoa)">Samoa (Batı Samoa)</option>
															<option value="Serbest Bölge (Ba-Bs)">Serbest Bölge (Ba-Bs)
															</option>
															<option value="Singapur">Singapur</option>
															<option value="Şili">Şili</option>
															<option value="Tacikistan">Tacikistan</option>
															<option value="Tayland">Tayland</option>
															<option value="Tayvan">Tayvan</option>
															<option value="Togo">Togo</option>
															<option value="Tokelau">Tokelau</option>
															<option value="Tonga">Tonga</option>
															<option value="Trinidad Ve Tobago">Trinidad Ve Tobago</option>
															<option value="Tunus">Tunus</option>
															<option value="Turks Ve Caicos Adas">Turks Ve Caicos Adas
															</option>
															<option value="Tuvalu">Tuvalu</option>
															<option value="Tanzanya (Birleşik C)">Tanzanya (Birleşik C)
															</option>
															<option value="Türkmenistan">Türkmenistan</option>
															<option value="Uganda">Uganda</option>
															<option value="Ukrayna">Ukrayna</option>
															<option value="Umman">Umman</option>
															<option value="Uruguay">Uruguay</option>
															<option value="Ürdün">Ürdün</option>
															<option value="Vanuatu">Vanuatu</option>
															<option value="Vatikan">Vatikan</option>
															<option value="Venezuella">Venezuella</option>
															<option value="Vietnam">Vietnam</option>
															<option value="Wallis Ve Futuna Ada">Wallis Ve Futuna Ada
															</option>
															<option value="Yakutistan">Yakutistan</option>
															<option value="Yemen">Yemen</option>
															<option value="Yeni Kalodenya Ve Ba">Yeni Kalodenya Ve Ba
															</option>
															<option value="Yeni Zelanda">Yeni Zelanda</option>
															<option value="Yeni Zelanda Okyanus">Yeni Zelanda Okyanus
															</option>
															<option value="Yugoslavya(Eski Yugo)">Yugoslavya(Eski Yugo)
															</option>
															<option value="Yugoslavya(Sirbistan)">Yugoslavya(Sirbistan)
															</option>
															<option value="Yunanistan">Yunanistan</option>
															<option value="Zambia">Zambia</option>
															<option value="Zimbabve">Zimbabve</option>-->
													</select>

												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Adres</label>
												<div class="col-sm-8">

														<textarea class="form-control" name="" id="adres_input"
																  style="resize: none;"></textarea>
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Düzenleme Tarihi</label>
												<div class="col-sm-9">
													<input type="text" class="datepicker form-control"
														   id="duzenlemeTarihi"
														   name="duzenlemeTarihi" autocomplete="off" required=""
														   value="<?php if ($invoice) echo $invoice["faturaTarihi"]; else echo getirBugunGib(); ?>"/>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Düzenleme Saati</label>
												<div class="col-sm-9">
													<input type="text" class="form-control" name="duzenlemeSaati"
														   autocomplete="off" required=""
														   value="<?php if ($invoice) echo $invoice["saat"]; else echo
														   getirSaatGib(); ?>"
														   id="datetimepicker"/>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Para Birimi</label>
												<div class="col-sm-5">
													<select class="form control select" name="paraBirimi"
															id="paraBirimi">
														<option value="TRY" <?php if ($invoice["paraBirimi"] == "TRY") echo "selected"; ?>>
															Türk Lirası
														</option>
														<option value="USD" <?php if ($invoice["paraBirimi"] == "USD") echo "selected"; ?>>
															Amerikan Doları
														</option>
														<option value="EUR" <?php if ($invoice["paraBirimi"] == "EUR") echo "selected"; ?>>
															Euro
														</option>
														<option value="GBP" <?php if ($invoice["paraBirimi"] == "GBP") echo "selected"; ?>>
															İngiliz Sterlini
														</option>
													</select>
												</div>
												<div class="col-sm-4">
													<input type="text" name="guncelKur" id="guncelKur"
														   class="form-control" placeholder="Döviz kuru"
														   value="<?php if ($invoice) echo $invoice["dovzTLkur"]; else echo "0"; ?>"/>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">Tip</label>
												<div class="col-sm-9" id="faturaTip_div">
													<select class="form-control" name="faturaTip"
															id="faturaTip" required="">
														<option value="SATIS" <?php if ($invoice["faturaTipi"] == "SATIS") echo "selected"; ?>>
															SATIŞ
														</option>
														<option value="IADE" <?php if ($invoice["faturaTipi"] == "IADE") echo "selected"; ?>>
															İADE
														</option>
														<option value="TEVKIFAT" <?php if ($invoice["faturaTipi"] == "TEVKIFAT") echo "selected"; ?>>
															TEVKİFAT
														</option>
														<option value="ISTISNA" <?php if ($invoice["faturaTipi"] == "ISTISNA") echo "selected"; ?>>
															İSTİSNA
														</option>
													</select>
												</div>

											</div>
										</div>
									</div>
								</div>

								<div class="row mt-4 pt-4 border-top">
									<div class="col-md-6">
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-sm-3 text-sm-left pt-2">İrsaliye Numarası</label>
												<div class="col-sm-9">
													<input type="text" class="datepicker form-control"
														   id="irsaliyeNo"
														   name="irsaliyeNo" autocomplete="off"
														   value="<?= $invoice["irsaliyeNumarasi"] ?>"/>
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="col-md-12">
											<div class="form-group row">
												<div class="col-sm-9">
													<input type="text" class="datepicker form-control"
														   id="irsaliyeTarihi"
														   name="irsaliyeTarihi" autocomplete="off"
														   value="<?= $invoice["irsaliyeTarihi"] ?>"/>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div class="row mt-4 mb-4 p-4 border-top border-bottom"
									 id="checkboxDiv">
									<div class="col-12 pl-4">
										<div class="row">
											<div class="col-md-4">

												<input class="form-check-input" type="checkbox" value="1"
													   id="kdvCheck" onchange="kdvCheckFunc()"
													   name="kdvCheck" style="width:30px;height:20px;">
												<label class="form-check-label ml-3" for="kdvCheck">
													KDV Dahil
												</label>

											</div>

											<div class="col-md-4">


												<input class="form-check-input ml-3" type="checkbox" value="1"
													   id="bankaCheck"
													   name="bankaCheck" style="width:30px;height:20px;">
												<label class="form-check-label ml-4 pl-4" for="bankaCheck">
													Banka Bilgisi Ekle
												</label>
											</div>

											<div class="col-md-4">
												<select class="form-control">

													<option>Vergi Seçiniz</option>
													<option value="V0021">BANKA MUAMELELERİ VER.</option>
													<option value="V0061">KKDF KESİNTİ</option>
													<option value="V0071">ÖTV 1. LİSTE</option>
													<option value="V9077">ÖTV 2. LİSTE</option>
													<option value="V0073">ÖTV 3. LİSTE</option>
													<option value="V0074">ÖTV 4. LİSTE</option>
													<option value="V0075">ÖTV 3A LİSTE</option>
													<option value="V0076">ÖTV 3B LİSTE</option>
													<option value="V0077">ÖTV 3C LİSTE</option>
													<option value="V1047">DAMGA V</option>
													<option value="V1048">5035SKDAMGAV</option>
													<option value="V4080">Ö.İLETİŞİM V</option>
													<option value="V4081">5035ÖZİLETV.</option>
													<option value="V9015">KDV TEVKİFAT</option>
													<option value="V9021">4961BANKASMV</option>
													<option value="V8001">BORSA TES.ÜC.</option>
													<option value="V8002">ENERJİ FONU</option>
													<option value="V4071">ELK.HAVAGAZ.TÜK.VER.</option>
													<option value="V8004">TRT PAYI</option>
													<option value="V8005">ELK.TÜK.VER.</option>
													<option value="V8006">TK KULLANIM</option>
													<option value="V8007">TK RUHSAT</option>
													<option value="V8008">ÇEV. TEM .VER.</option>
													<option value="V0003">GV. STOPAJI</option>
													<option value="V0011">KV. STOPAJI</option>
													<option value="V9040">MERA FONU</option>
													<option value="V4171">ÖTV 1. LİSTE TEVKİFAT</option>
													<option value="V9944">BEL.ÖD.HAL RÜSUM</option>
												</select>
											</div>
										</div>
									</div>
								</div>

								<div class="row" style="display: none;"
									 id="iade_fatura_bilgi">
									<div class="col-md-12">
										<h4 class="card-title mt-4">İade Fatura Bilgisi </h4>
										<div class="row">
											<div class="table-responsive">
												<input type="hidden" name="iade_count" id="iade_count">
												<table class="table table-bordered custom-table mb-0" id="my_table">
													<tbody id="tbody_iade">

													</tbody>
												</table>
											</div>
										</div>
									</div>

								</div>


								<div class="row"
									 id="stokBilgisiDiv">
									<div class="col-md-12">
										<h4 class="card-title mt-4">Stok Bilgisi <i
													class="fa fa-info-circle fa-xs text-info" data-toggle="tooltip"
													data-placement="right"
													title="Tablonun istediğiniz kenarından tutup büyütme ve küçültme işlemi yapabilirsiniz."></i>

											<a href="javascript:void(0)" class="btn btn-success btn-sm"
											   onclick="addItem();" style="float:right;"><i class="fa fa-plus"></i>
												Yeni
												Satır Ekle</a>
											<a href="javascript:void(0)" class="btn btn-info btn-sm mr-2"
											   style="float:right;"
											   onclick="addIndirim();$('#genel_iskonto').attr('style', 'display:block;');"><i
														class="fa fa-plus"></i>
												Genel İskonto</a>
										</h4>

										<div class="row">
											<div class="table-responsive">
												<table class="table table-bordered custom-table mb-0" id="my_table">
													<thead>
													<tr>
														<th>Stok Adı</th>
														<th>Birim</th>
														<th>Miktar</th>
														<th>Birim Fiyat <span id="birimFiyatParaBirimi">(TL)</span></th>
														<th>KDV (%)</th>
														<th>Toplam</th>
														<th></th>
													</tr>
													</thead>
													<tbody id="tbody">
													<script>var items=0;</script>
													<?php
													if ($invoice) {
														$items = 1;

													$malhizmet = $invoice["malHizmetTable"];
													foreach ($malhizmet as $item) {?>
														<script>items++;</script>
													<tr>
														<td>
															<input type='text' class='form-control' name='stokadi[]'
																   id='stokadi<?= $items ?>' required value="<?= $item["malHizmet"] ?>">
														</td>
														<td>
															<select class='form-control' name='birim[]'
																	id='birim<?= $items ?>'>
																<?= $birimler ?>
															</select>
															<script>

																document.getElementById("birim"+items).value="<?= $item["birim"] ?>";
															</script>
														</td>
														<td>
															<input type='number' step='0.1' class='form-control'
																   autocomplete='off' name='miktar[]'
																   id='miktar<?= $items ?>' required=''
																   style='width:175px;' value="<?= $item["miktar"] ?>">
														</td>
														<td>
															<input type='number' step='0.1' class='form-control'
																   autocomplete='off' name='birimfiyat[]'
																   id='birimfiyat<?= $items ?>' required=''value="<?= $item["birimFiyat"] ?>">
														</td>
														<td>
															<select class='form-control' name='kdv[]'
																	id='kdv<?= $items ?>'>
																<option value='0' <?php if($item["kdvOrani"]==0) echo "selected"; ?>>0</option>
																<option value='1' <?php if($item["kdvOrani"]==1) echo "selected"; ?>>1</option>
																<option value='8'  <?php if($item["kdvOrani"]==8) echo "selected"; ?>>8</option>
																<option value='18' <?php if($item["kdvOrani"]==18) echo "selected"; ?>>18</option>
															</select>
														</td>
														<td>
															<input type='hidden' name='indirimtutari[]'
																   id='indirimtutari<?= $items ?>>' value="<?= $item["iskontoTutari"] ?>">
															<input type='text' class='form-control' name='toplam[]'
																   id='toplam<?= $items ?>' readonly value="<?= $item["malHizmetTutari"] ?>">
															<input type='hidden' name='toplamHidden[]' value="<?= $item["malHizmetTutari"] ?>"
																   id='toplamHidden<?= $items ?>'>
														</td>
														<td>
															<button type='button' class='btn btn-info btn-sm'
																	data-toggle='modal' data-target='#add_category'
																	data-idsi='<?= $items ?>'
																	id='eklebuton<?= $items ?>'><i
																		class='fa fa-plus'></i> Ekle
															</button>
															<button type='button' onclick='deleteRow(this);'
																	class='btn btn-danger btn-sm' id='<?= $items ?>>'><i
																		class='fa fa-trash'></i> Sil
															</button>
														</td>
													</tr>

													<td id='indirimytd<?= $items ?>>' <?php if($item["iskontoOrani"]=="") echo "style='display: none;'";?>>
														<label>İndirim (%)</label>
														<input type='number' step='0.1' class='form-control'
															   placeholder='İndirim (%)' name='indirimyuzde[]'
															   id='indirimyuzde<?= $items ?>' value="<?= $item["iskontoOrani"] ?>">
													</td>
													<td id='tevkifatselecttd<?= $items ?>' style='display: none;'>
														<label>Tevkifat</label>
														<select name='tevkifat[]' id='tevkifat<?= $items ?>'
																class='form-control'
																onchange='tevkifat(this,<?= $items ?>)'>
															<option value='0'>Seçiniz</option>
															<?php echo $tevkifat; ?>
														</select>
													</td>
													<td id='tevkifattexttd<?= $items ?>' style='display: none;'>
														<label>Tevkifat Oranı(%)</label>
														<input type='text' class='form-control' name='tevkifat_oran[]'
															   id='tevkifat_oran<?= $items ?>' readonly
															   placeholder='Tevkifat Oranı(%)'>
													</td>

													<?php
													$items++;

													}?>

													<?php }
													?>
													</tbody>

												</table>
											</div>
										</div>

										<div class="row" style="display: none;"
											 id="genel_iskonto">
											<div class="col-md-12">
												<h4 class="card-title mt-4">GENEL İNDİRİM ISKONTO </h4>
												<div class="row">
													<div class="table-responsive">
														<input type="hidden" name="indirim_count"
															   id="indirim_count">
														<table class="table table-bordered custom-table mb-0"
															   id="my_table">
															<tbody id="tbody_indirim">

															</tbody>
														</table>
													</div>
												</div>
											</div>

										</div>

										<div class="row " style="display: none;"
											 id="vergiMuafiyet">
											<div class="col-md-12">
												<h4 class="card-title mt-4">VERGİ MUAFİYET </h4>
												<table class="table custom-table mb-0">
													<tr>
														<td style="width:5%;"><label>Vergi Muafiyet Sebebi</label>
														</td>
														<td>
															<input type="text" name="vergiMuafiyet_sebep"
																   id="vergiMuafiyet_sebep" class="form-control"
																   value="">
														</td>
													</tr>
												</table>
											</div>
										</div>

										<div class="row" style="display: none;"
											 id="istisna_table">
											<div class="col-md-12">
												<h4 class="card-title mt-4">VERGİ MUAFİYET </h4>
												<p style="font-style:italic;color:red;">
													! İhracat faturasında 301 nolu kodu kullanız . .<br>
													! İhracat kayıtlı faturalarda 701 , 702 veya 703 nolu kodlar
													kullanız . .
												</p>
												<table class="table custom-table mb-0">
													<tr>
														<td style="width:5%;"><label>İstisna Sebebi</label></td>
														<td>
															<select class="form-control" name='istisna_sebebi'
																	id='istisna_sebebi'>
																<option value="0">Seçiniz</option>
																<?= $istisna; ?>
															</select>
														</td>
													</tr>
												</table>
											</div>
										</div>

										<div class="row" style="display: none;"
											 id="bankabilgileri" style="display: none;">
											<div class="col-md-12">
												<h4 class="card-title mt-4">Banka Bilgileri</h4>
												<input type="hidden" name="bankaCount" id="bankaCount">
												<table class="table table-bordered custom-table mb-0" id="my_table">
													<tbody id="tbody_ayarlarbanka">
													</tbody>
												</table>
											</div>
										</div>


										<div class="row">
											<div class="table-responsive">

												<table class="table table-stripped table-center table-hover">
													<thead></thead>
													<tbody>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-right">Ara Toplam</td>
														<td class="text-right"
															id="aratop"></td>
													</tr>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-right">Toplam İskonto(İndirim)</td>
														<td class="text-right"
															id="indirimtop"></td>
													</tr>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-right">Net Tutar(Matrah)</td>
														<td class="text-right"
															id="nettutartop"></td>
													</tr>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-right">Hesaplanan KDV</td>
														<td class="text-right"
															id="kdvtop"></td>
													</tr>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-right">Hesaplanan KDV Tevkifat</td>
														<td class="text-right"
															id="kdvtevkifat"></td>
													</tr>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-right">Vergiler Dahil Ödenecek Tutar</td>
														<td class="text-right"
															id="vergidahil"></td>
													</tr>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-right">Genel Toplam</td>
														<td class="text-right"
															id="geneltop"></td>
													</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>

								<div class="row"
									 id="faturaAltBilgisiDiv">
									<div class="col-md-12">
										<h4 class="card-title mt-4">Fatura Alt Bilgileri</h4>
										<div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label>Açıklama</label>
													<textarea class="form-control"
															  name="aciklama"></textarea>
												</div>
											</div>
										</div>

										<div class="col-md-12 p-0">
											<div class="row">
												<div class="col-md-12">
													<button type="submit" class="btn btn-danger" style="width:100%;"
															id="submitBtn">
														Kaydet
													</button>
												</div>
											</div>
										</div>
									</div>
								</div>


								<input type="hidden" id="aratopHidden" name="aratopHidden"
									   value="">
								<input type="hidden" id="kdvtopHidden" name="kdvtopHidden"
									   value="">
								<input type="hidden" id="geneltopHidden" name="geneltopHidden"
									   value="">
								<input type="hidden" id="vergidahilHidden" name="vergidahilHidden"
									   value="">
								<input type="hidden" id="indirimtopHidden" name="indirimtopHidden"
									   value="">
								<input type="hidden" id="tevkifattopHidden" name="tevkifattopHidden"
									   value="">
								<input type="hidden" id="netTutarInput" name="netTutarInput"
									   value="">
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- /Page Wrapper -->

</div>
<!-- /Main Wrapper -->


<div id="add_category" class="modal custom-modal fade" role="dialog">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">İşlem Seçiniz</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="#" method="POST">
					<input class="form-control" type="hidden" id="add_idsi" name="id">

					<select name="add_secim[]" multiple id="add_secim" class="form-control select"
							placeholder="Seçiniz...">
						<option value="1">İndirim (%)</option>
					</select>

					<div class="submit-section">
						<a class="btn btn-danger" id="ekle_kaydet">Ekle</a>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Kapat</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>


<?php $this->load->view("include/footer-js"); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
		integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
		crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!--<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script> -->
<script>
	$(function () {
		$('.datepicker').datepicker({
			dateFormat: 'dd/mm/yy',
			language: 'tr'/*,
			autoclose: true,
			todayHighlight: true,
			format: 'mm/dd/yyyy',
			startDate: new Date(new Date().setDate(new Date().getDate() -7)),
			endDate: new Date(new Date())*/
		});
	});

	$(function () {
		$('#datetimepicker').datetimepicker({
			format: 'HH:mm:ss'
		});
	});
</script>


<script>

	function kdvCheckFunc() {

		if (document.getElementById("kdvCheck").checked == true) {
			$('input[name^="birimfiyat"]').prop('readonly', true);
			$('input[name^="toplam"]').prop('readonly', false);
		} else {
			$('input[name^="birimfiyat"]').prop('readonly', false);
			$('input[name^="toplam"]').prop('readonly', true);
		}
		hesapla();

	}

	$(document).on('change', 'input[id="bankaCheck"]', function () {
		//function bankaCheckFunc(){
		if (document.getElementById("bankaCheck").checked == true) {
			$("#bankabilgileri").css("display", "block");

			var row = document.getElementById("tbody_ayarlarbanka");
			row.innerHTML = "";
			if (checkboxbanka == 1) {
				<?php  $items_banka = 0;foreach ($faturabankaDuzenle as $item) {
				$items_banka++;
				/*echo "items_banka++; counter_banka.push(items_banka); document.getElementById('bankaCount').value =items_banka;";*/
				$html = "<tr>";
				$html .= '<td><label>Banka Adı</label><input type="hidden" name="ayarlarbanka_id[]" id="ayarlarbanka_id' . $items_banka . '" value="' . $item->ayarlarbanka_id . '"><input type="text" class="form-control" name="ayarlar_bankaadi[]" id="ayarlar_bankaadi' . $items_banka . '" value="' . $item->ayarlarbanka_ad . '"></td>';
				$html .= '<td><label>Şube</label><input type="text" class="form-control" name="ayarlar_sube[]" id="ayarlar_sube' . $items_banka . '" value="' . $item->ayarlarbanka_subeAd . '"></td>';

				$html .= '<td><label>Para Birimi</label><select class="form-control" name="ayarlar_parabirimi" id="ayarlar_parabirimi' . $items_banka . '"><option value="1"';
				if ($item->ayarlarbanka_paraBirim == 1) $html .= " selected ";
				$html .= '>Türk Lirası</option><option value="2"';
				if ($item->ayarlarbanka_paraBirim == 2) $html .= " selected ";
				$html .= '>Amerikan Doları </option><option value="3"';
				if ($item->ayarlarbanka_paraBirim == 3) $html .= " selected ";
				$html .= '>Euro</option><option value="4"';
				if ($item->ayarlarbanka_paraBirim == 4) $html .= " selected ";
				$html .= '> İngiliz Sterlini </option> </select> </td>"';

				$html .= '<td><label>Hesap No</label><input type="text" class="form-control" name="ayarlar_hesapno[]" id="ayarlar_hesapno' . $items_banka . '"  value="' . $item->ayarlarbanka_hesapNo . '"></td>';
				$html .= '<td><label>IBAN</label><input type="text" class="form-control" name="ayarlar_iban[]" id="ayarlar_iban' . $items_banka . '"  value="' . $item->ayarlarbanka_iban . '"></td>';

				$html .= '<td><button type="button" onclick="deleteRowBanka(this);" class="btn btn-danger btn-sm" id="' . $items_banka . '"><i class="fa fa-trash"></i> Sil</button></td>';
				$html .= "</tr>";
				echo 'row=document.getElementById("tbody_ayarlarbanka").insertRow();row.innerHTML=\'' . $html . '\';';
				echo "items_banka=" . $items_banka . "; counter_banka.push(" . $items_banka . ");document.getElementById('bankaCount').value=" . $items_banka . ";";
				}?>
			} else {
				<?php  foreach ($faturabanka as $itemx) {
				$items_banka++;
				$html = "<tr>";
				$html .= '<td><label>Banka Adı</label><input type="hidden" name="ayarlarbanka_id[]" id="ayarlarbanka_id' . $items_banka . '" value="' . $itemx->ayarlarbanka_id . '"><input type="text" class="form-control" name="ayarlar_bankaadi[]" id="ayarlar_bankaadi' . $items_banka . '" value="' . $itemx->ayarlarbanka_ad . '"></td>';
				$html .= '<td><label>Şube</label><input type="text" class="form-control" name="ayarlar_sube[]" id="ayarlar_sube' . $items_banka . '" value="' . $itemx->ayarlarbanka_subeAd . '"></td>';

				$html .= '<td><label>Para Birimi</label><select class="form-control" name="ayarlar_parabirimi" id="ayarlar_parabirimi' . $items_banka . '"><option value="1"';
				if ($itemx->ayarlarbanka_paraBirim == 1) $html .= " selected ";
				$html .= '>Türk Lirası</option><option value="2"';
				if ($itemx->ayarlarbanka_paraBirim == 2) $html .= " selected ";
				$html .= '>Amerikan Doları </option><option value="3"';
				if ($itemx->ayarlarbanka_paraBirim == 3) $html .= " selected ";
				$html .= '>Euro</option><option value="4"';
				if ($itemx->ayarlarbanka_paraBirim == 4) $html .= " selected ";
				$html .= '> İngiliz Sterlini </option> </select> </td>"';

				$html .= '<td><label>Hesap No</label><input type="text" class="form-control" name="ayarlar_hesapno[]" id="ayarlar_hesapno' . $items_banka . '"  value="' . $itemx->ayarlarbanka_hesapNo . '"></td>';
				$html .= '<td><label>IBAN</label><input type="text" class="form-control" name="ayarlar_iban[]" id="ayarlar_iban' . $items_banka . '"  value="' . $itemx->ayarlarbanka_iban . '"></td>';

				$html .= '<td><button type="button" onclick="deleteRowBanka(this);" class="btn btn-danger btn-sm" id="' . $items_banka . '"><i class="fa fa-trash"></i> Sil</button></td>';
				$html .= "</tr>";
				echo 'row=document.getElementById("tbody_ayarlarbanka").insertRow();row.innerHTML=\'' . $html . '\';';
				}

				echo "items_banka=" . $items_banka . "; counter_banka.push(" . $items_banka . ");document.getElementById('bankaCount').value=" . $items_banka . ";";
				?>


			}
		} else {
			$("#bankabilgileri").css("display", "none");
			checkboxbanka = 0;
		}

	});


	function addItem() {

		items++;
		counter.push(items);
		var html = "<tr>";
		html += "<td><input type='text' class='form-control' name='stokadi[]' id='stokadi" + items + "'  required></td>";
		html += "<td><select class='form-control' name='birim[]' id='birim" + items + "'><?= $birimler ?></select></td>";
		html += "<td><input type='number' step='0.1' class='form-control' autocomplete='off' name='miktar[]' id='miktar" + items + "' required='' style='width:175px;' ></td>";
		html += "<td><input type='number' step='0.1' class='form-control' autocomplete='off' name='birimfiyat[]' id='birimfiyat" + items + "' required='' ></td>";
		/*html += "<td><input type='text' class='form-control' name='kdv[]' id='kdv"+items+"' readonly></td>";*/
		html += "<td><select class='form-control' name='kdv[]' id='kdv" + items + "' ><option value='0' >0</option><option value='1 '>1</option><option value='8' selected>8</option><option value='18'>18</option></select></td>";
		html += "<td><input type='hidden' name='indirimtutari[]' id='indirimtutari" + items + "'><input type='text' class='form-control' name='toplam[]' id='toplam" + items + "' readonly><input type='hidden' name='toplamHidden[]' id='toplamHidden" + items + "'></td>";
		html += "<td><button type='button' class='btn btn-info btn-sm' data-toggle='modal' data-target='#add_category' data-idsi='" + items + "' id='eklebuton" + items + "' ><i class='fa fa-plus'></i> Ekle</button> <button type='button' onclick='deleteRow(this);' class='btn btn-danger btn-sm' id='" + items + "'><i class='fa fa-trash'></i> Sil</button> </td>";
		html += "</tr>";
		var row = document.getElementById("tbody").insertRow();
		row.innerHTML = html;
		var secenekler = "<td id='indirimytd" + items + "' style='display: none;'><label>İndirim (%)</label><input type='number' step='0.1' class='form-control' placeholder='İndirim (%)' name='indirimyuzde[]'   id='indirimyuzde" + items + "'></td>";
		secenekler += "<td id='tevkifatselecttd" + items + "' style='display: none;' ><label>Tevkifat</label><select  name='tevkifat[]'  id='tevkifat" + items + "'class='form-control' onchange='tevkifat(this," + items + ")'><option value='0'>Seçiniz</option><?php echo $tevkifat; ?></select></td>";
		secenekler += "<td id='tevkifattexttd" + items + "' style='display: none;' ><label>Tevkifat Oranı(%)</label><input type='text' class='form-control' name='tevkifat_oran[]' id='tevkifat_oran" + items + "' readonly placeholder='Tevkifat Oranı(%)'></td>";


		var row = document.getElementById("tbody").insertRow();
		row.innerHTML = secenekler;


		if (document.getElementById("kdvCheck").checked == true) {
			$('input[name^="birimfiyat"]').prop('readonly', true);
			$('input[name^="toplam"]').prop('readonly', false);
		} else {
			$('input[name^="birimfiyat"]').prop('readonly', false);
			$('input[name^="toplam"]').prop('readonly', true);
		}

	}

<?php if(!$invoice)
	echo "addItem();";
else
	echo "hesapla();";
?>

	function addIndirim() {
		items_indirim++;
		counter_indirim.push(items_indirim);
		var html_indirim = "<tr>";
		html_indirim += "<td>Sebebi </td>";
		html_indirim += "<td><select class='form-control select' name='indirimsebep[]' id='indirimsebep" + items_indirim + "'><option value='0'>İskonto</option><option value='1'>Nakit İskontosu</option><option value='2'>Diğer</option></select></td>";
		html_indirim += "<td>Tutar </td>";
		html_indirim += "<td><input type='number' class='form-control' name='indirimtutar[]' id='indirimtutar" + items_indirim + "' placeholder='İndirim (%)'></td>";
		html_indirim += "<td><button type='button' onclick='deleteRowIndirim(this);' class='btn btn-danger btn-sm' id='" + items + "'><i class='fa fa-trash'></i> Sil</button> </td>";
		html_indirim += "</tr>";

		var rowIndirim = document.getElementById("tbody_indirim").insertRow();
		rowIndirim.innerHTML = html_indirim;
		$("#indirim_count").val(items_indirim);
	}

	function tevkifat(object, items) {
		var val = object.value;
		val = (val.split("|"))[0];
		val = val * 100;
		$("#tevkifat_oran" + items).val(val);
		hesapla();
	}

	function round(value, decimals) {
		if (value != "NaN") {
			//return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals);/*
			var x = value;
			var array = x.toString().split(".");
			x = array[1];
			var ondalik = x.substr(0, 2);
			if (parseInt(x[1]) % 2 == 0) {
				return Number(array[0] + "." + ondalik);
			} else {
				return Number(Math.ceil(value + 'e' + decimals) + 'e-' + decimals);
			}
		}

	}

	function hesapla() {
		var aratop = 0;
		var kdvtop = 0;
		var geneltop = 0;
		var nettop = 0;
		var fiyat = 0;
		var indirimtop = 0;
		var tevkifattop = 0;
		//debugger;


		for (i = 1; i <= items; i++) {
			var satir = $("#stokadi" + i).val();
			if (satir != "") {
				fiyat = 0;
				var miktar = $("#miktar" + i + "").val();
				var toplam = $("#toplam" + i + "").val();
				var birimfiyat = $("#birimfiyat" + i + "").val();

				var kdvoran = $("#kdv" + i).val();
				var kdvHesap = 0;
				var indirimyuzde = $("#indirimyuzde" + i).val();
				//var indirimtutari = $("#indirimtutari" + i).val();
				var tevkifat = $("#tevkifat" + i).val();
				tevkifat = (tevkifat.split("|"))[0];
				if (document.getElementById("kdvCheck").checked == true) {
					birimfiyat = miktar * kdvoran / 100;
					birimfiyat += parseFloat(miktar);
					birimfiyat = parseFloat(toplam) / birimfiyat;

					//birimfiyat=100/(miktar+(miktar*kdvoran/100));

					$("#birimfiyat" + i + "").val(round(birimfiyat.toFixed(3), 4));
				}
				fiyat = miktar * birimfiyat;

				aratop += fiyat;//ara toplam


				if (indirimyuzde != "") {
					var indirimtutari = fiyat * indirimyuzde / 100;
					indirimtop += parseFloat(indirimtutari); //toplam indirim
					fiyat = fiyat - parseFloat(indirimtutari);
				}

				if (items_indirim != 0) {
					var iskonto = iskontoHesapla(fiyat);

					iskonto = iskonto.toString().split("|");
					fiyat = parseFloat(iskonto[0]);
					indirimtop += parseFloat(iskonto[1]);
				}
				if (document.getElementById("kdvCheck").checked == false)
					$("#toplam" + i + "").val(formatter.format(round(fiyat.toFixed(3), 2)));

				$("#toplamHidden" + i + "").val(round(fiyat.toFixed(3), 2));

				var a = document.getElementById("toplamHidden" + i + "").value;


				kdvHesap = fiyat * parseFloat(kdvoran) / 100;
				kdvtop += kdvHesap;

				kdvtop = round(kdvtop.toFixed(3), 2);
				if (!isNaN(tevkifat) && tevkifat != 0) {
					tevkifat = kdvHesap * tevkifat;
					tevkifattop = tevkifattop + tevkifat;

				}

			}

			nettop = aratop - indirimtop;
			geneltop = nettop + kdvtop;

			$("#vergidahil").html(formatter.format(round(geneltop.toFixed(3), 2)) + " " + paraBirimiMetin);
			$("#vergidahilHidden").val(round(geneltop.toFixed(3), 2));
			geneltop = round(geneltop.toFixed(3), 2) - round(tevkifattop.toFixed(3), 2);


			$("#aratop").html(formatter.format(round(aratop.toFixed(3), 2)) + " " + paraBirimiMetin);
			$("#aratopHidden").val(round(aratop.toFixed(3), 2));
			$("#kdvtop").html(formatter.format(round(kdvtop.toFixed(3), 2)) + " " + paraBirimiMetin);
			$("#kdvtopHidden").val(round(kdvtop.toFixed(3), 2));
			$("#geneltop").html(formatter.format(round(geneltop.toFixed(3), 2)) + " " + paraBirimiMetin);
			$("#geneltopHidden").val(round(geneltop.toFixed(3), 2));

			$("#netTutarInput").val(round(nettop.toFixed(3), 2));

			$("#nettutartop").html(formatter.format(round(nettop.toFixed(3), 2)) + " " + paraBirimiMetin);

			$("#indirimtop").html(formatter.format(round(indirimtop.toFixed(3), 2)) + " " + paraBirimiMetin);
			$("#indirimtopHidden").val(round(indirimtop.toFixed(3), 2));


			$("#kdvtevkifat").html(formatter.format(round(tevkifattop.toFixed(3), 2)) + " " + paraBirimiMetin);
			$("#tevkifattopHidden").val(round(tevkifattop.toFixed(3), 2));


		}
	}

	function iskontoHesapla(toplamsatir) {

		var toplamindirim = 0;

		for (k = 1; k <= items_indirim; k++) {
			var iskonto = 0;
			var tutar = $("#indirimtutar" + k + "").val();
			var hesap = $.trim(tutar).length;
			if (hesap != 0) {

				iskonto = toplamsatir * tutar / 100;

				toplamindirim += iskonto;
				toplamsatir = toplamsatir - iskonto;
			}
		}


		return toplamsatir + "|" + toplamindirim;
	}

	function deleteRow(button) {

		if (counter.length >= 1) {
			counter.pop();
		}
		if (counter.length == 0) {
			counter.push(1);
			toastr.warning("En az bir kayıt olması zorunludur, bu kayıt silinemez.");
		} else {

			var btnID = button.id;

			//items--;


			var btnID = button.id;

			button.parentElement.parentElement.remove();
			$('#bos' + btnID + '').remove();
			$('#indirimytd' + btnID + '').remove();
			$('#indirimttd' + btnID + '').remove();
			$('#tevkifattd' + btnID + '').remove();
			$('#istisnatd' + btnID + '').remove();
			$('#tevkifatselecttd' + btnID + '').remove();
			$('#tevkifattexttd' + btnID + '').remove();
			hesapla();

		}
	}

	toastr.options = {
		"closeButton": true,
		"debug": false,
		"newestOnTop": false,
		"progressBar": true,
		"positionClass": "toast-top-right",
		"preventDuplicates": false,
		"onclick": null,
		"showDuration": "300",
		"hideDuration": "1000",
		"timeOut": "5000",
		"extendedTimeOut": "1000",
		"showEasing": "swing",
		"hideEasing": "linear",
		"showMethod": "fadeIn",
		"hideMethod": "fadeOut"
	};


	$('#add_category').on('show.bs.modal', function (event) {
		let a_idsi = $(event.relatedTarget).data('idsi')
		$(this).find('.modal-body #add_idsi').val(a_idsi)
	})


	function vergimuafiyet() {
		$("#vergiMuafiyet").css("display", "none");
		document.getElementById("vergiMuafiyet_sebep").required = false;
		var sonuc = 0;
		for (i = 1; i <= items; i++) {
			var val = $("#kdv" + i).val();
			if (val == 0) {
				sonuc = 1;
				break;
			}
		}
		if (sonuc == 1) {
			$("#vergiMuafiyet").css("display", "block");
			document.getElementById("vergiMuafiyet_sebep").required = true;
		}
	}

	$(document).on('change', 'select[name^="kdv"]', function () {
		var tip = $("#faturaTip").val();
		if (tip != 4)
			vergimuafiyet();
		hesapla();
	});

	$(document).on('change', 'input[name^="miktar"]', function () {
		hesapla();

	});

	$(document).on('change', 'input[name^="birimfiyat"]', function () {
		hesapla();

	});

	$(document).on('change', 'input[name^="indirimyuzde"]', function () {
		/*
				let indirimtop = 0;

				let id = event.target.id;
				var numb = id.match(/\d/g);
				numb = numb.join("");

				var indirimyuzde = $("#indirimyuzde" + numb + "").val();
				var toplam = $("#toplam" + numb + "").val();

				var indirimtutari = toplam * indirimyuzde / 100;

				$("#indirimtutari" + numb + "").val(indirimtutari);

				for (i = 1; i <= items; i++) {
					var tutar = $("#indirimtutari" + i + "").val();
					var hesap = $.trim(tutar).length;
					if (hesap != 0)
						indirimtop = indirimtop + parseFloat($("#indirimtutari" + i + "").val());
				}

				$("#indirimtop").html(formatter.format(indirimtop) + " " + paraBirimiMetin);

				$("#indirimtopHidden").val(indirimtop);*/
		let id = event.target.id;
		var numb = id.match(/\d/g);
		numb = numb.join("");

		var indirimyuzde = $("#indirimyuzde" + numb + "").val();
		if (indirimyuzde == "100") {

			$("#vergiMuafiyet").css("display", "block");
			document.getElementById("vergiMuafiyet_sebep").required = true;
			vergimuafiyet();
		} else {

			$("#vergiMuafiyet").css("display", "none");
			document.getElementById("vergiMuafiyet_sebep").required = false;
			vergimuafiyet();

		}
		hesapla();


	});

	$(document).on('change', 'input[name^="toplam"]', function () {
		hesapla();
	});

	$(document).on('change', 'input[name^="indirimtutar"]', function () {

		let id = event.target.id;
		var numb = id.match(/\d/g);
		numb = numb.join("");

		var indirimtutar = $("#indirimtutar" + numb + "").val();
		if (indirimtutar == "100") {

			$("#vergiMuafiyet").css("display", "block");
			document.getElementById("vergiMuafiyet_sebep").required = true;
		} else {

			$("#vergiMuafiyet").css("display", "none");
			document.getElementById("vergiMuafiyet_sebep").required = false;

		}
		hesapla();


	});
</script>

<script>


	$("#submitBtn").click(function (e) {
		let allAreFilled = true;
		document.getElementById("myForm").querySelectorAll("[required]").forEach(function (i) {
			if (!allAreFilled) return;
			if (!i.value) allAreFilled = false;
			if (i.type === "radio") {
				let radioValueCheck = false;
				document.getElementById("myForm").querySelectorAll(`[name=${i.name}]`).forEach(function (r) {
					if (r.checked) radioValueCheck = true;
				})
				allAreFilled = radioValueCheck;
			}
		})
		if (!allAreFilled) {
			toastr.error("Bütün gerekli alanları doldurup tekrar deneyiniz.");
		} else {
			$("#myForm").submit();
		}
	});

	//döviz kuru işlemleri buradan
	$("#paraBirimi").on('change', function () {
		var paraBirimiText = $("#paraBirimi option:selected").text();
		var paraBirimi = $("#paraBirimi option:selected").val();

		if (paraBirimi == 1) {
			$("#guncelKur").css("display", "none");
			$("#aguncelKur").val("");
			$("#birimFiyatParaBirimi").html("(TL)");
			paraBirimiMetin = "TL";
		} else {
			if (paraBirimi == 2) {
				$("#birimFiyatParaBirimi").html("(USD)");
				paraBirimiMetin = "USD";
			} else if (paraBirimi == 3) {
				$("#birimFiyatParaBirimi").html("(EUR)");
				paraBirimiMetin = "EUR";
			} else if (paraBirimi == 4) {
				$("#birimFiyatParaBirimi").html("(GBP)");
				paraBirimiMetin = "GBP";
			}

			$("#guncelKur").css("display", "block");
			$.ajax({
				url: "<?= env('BASE_URL'); ?>/fatura/paraBirimiKontrol",
				method: "POST",
				data: {paraBirimi: paraBirimi},
				success: function (result) {
					toastr.success("Para birimi " + paraBirimiText + " olarak değiştirilmiştir. Güncel kur bilgileri ekrana yansıtılmıştır.");
					$("#guncelKur").val(result);
				}
			});
		}
		hesapla();
	});

	$("#ekle_kaydet").click(function (e) {

		e.preventDefault();
		$('#add_category').modal('toggle');

		let idsi = $("#add_idsi").val();
		let secim = $("#add_secim").val();
		var indirimyuzde = 0, indirimtutar = 0, tevkifat = 0, istisna = 0;
		if ($("#indirimyuzde" + idsi).length != 0) {
			indirimyuzde = 1;
		}
		if ($("#indirimtutar" + idsi).length != 0) {
			indirimtutar = 1;
		}
		if ($("#tevkifat" + idsi).length != 0) {
			tevkifat = 1;
		}
		if ($("#istisna" + idsi).length != 0) {
			istisna = 1;
		}


		let html = '';

		let array = secim.toString().split(",");

		$.each(array, function (i) {

			if (array[i] == 1) {
				$("#indirimytd" + idsi).show();

			} else if (array[i] == 3) {
				$("#tevkifatselecttd" + idsi).show();
				$("#tevkifattexttd" + idsi).show();
			}
		});

		$('#my_table > #tbody > tr').eq(idsi - 1).after(html);

		$("#add_secim").val([]).change();
	});

	$("#faturaTip").on('change', function () {
		var val = $(this).val();
		$("#add_secim option[value='3']").remove();
		$('#iade_fatura_bilgi').attr('style', 'display:none;');
		$('#istisna_table').attr('style', 'display:none;');
		document.getElementById("istisna_sebebi").value = "0";
		document.getElementById("istisna_sebebi").required = false;


		var rowIade = document.getElementById("tbody_iade");
		rowIade.innerHTML = "";


		$("#iade_count").val(0);
		counter_iade = [];

		if (val != 4 && val != 5)
			vergimuafiyet();
		else {
			$("#vergiMuafiyet").css("display", "none");
			document.getElementById("vergiMuafiyet_sebep").required = false;
		}

		$('.ek_satir').remove();


		if (val == 1) {//satış

		} else if (val == 2) {//iade
			$('#iade_fatura_bilgi').attr('style', 'display:block;');

			addItemIade();
		} else if (val == 3) {//tevkifat

			var x = document.getElementById("add_secim");
			var option = document.createElement("option");
			option.text = "Tevkifat";
			option.value = "3";
			x.add(option);

		} else if (val == 4) {//istisna

			$('#istisna_table').attr('style', 'display:block;');
			debugger;
			document.getElementById("istisna_sebebi").required = true;
		}

	});

</script>

<script>
	//var tables = document.getElementsByClassName('flexiCol');
	var tables = document.getElementsByTagName('table');
	for (var i = 0; i < tables.length; i++) {
		resizableGrid(tables[i]);
	}

	function resizableGrid(table) {
		var row = table.getElementsByTagName('tr')[0],
			cols = row ? row.children : undefined;
		if (!cols) return;

		table.style.overflow = 'hidden';

		var tableHeight = table.offsetHeight;

		for (var i = 0; i < cols.length; i++) {
			var div = createDiv(tableHeight);
			cols[i].appendChild(div);
			cols[i].style.position = 'relative';
			setListeners(div);
		}

		function setListeners(div) {
			var pageX, curCol, nxtCol, curColWidth, nxtColWidth;

			div.addEventListener('mousedown', function (e) {
				curCol = e.target.parentElement;
				nxtCol = curCol.nextElementSibling;
				pageX = e.pageX;

				var padding = paddingDiff(curCol);

				curColWidth = curCol.offsetWidth - padding;
				if (nxtCol)
					nxtColWidth = nxtCol.offsetWidth - padding;
			});

			div.addEventListener('mouseover', function (e) {
				e.target.style.borderRight = '2px solid #d92637';
			})

			div.addEventListener('mouseout', function (e) {
				e.target.style.borderRight = '';
			})

			document.addEventListener('mousemove', function (e) {
				if (curCol) {
					var diffX = e.pageX - pageX;

					if (nxtCol)
						nxtCol.style.width = (nxtColWidth - (diffX)) + 'px';

					curCol.style.width = (curColWidth + diffX) + 'px';
				}
			});

			document.addEventListener('mouseup', function (e) {
				curCol = undefined;
				nxtCol = undefined;
				pageX = undefined;
				nxtColWidth = undefined;
				curColWidth = undefined
			});
		}

		function createDiv(height) {
			var div = document.createElement('div');
			div.style.top = 0;
			div.style.right = 0;
			div.style.width = '5px';
			div.style.position = 'absolute';
			div.style.cursor = 'col-resize';
			div.style.userSelect = 'none';
			div.style.height = height + 'px';
			return div;
		}

		function paddingDiff(col) {

			if (getStyleVal(col, 'box-sizing') == 'border-box') {
				return 0;
			}

			var padLeft = getStyleVal(col, 'padding-left');
			var padRight = getStyleVal(col, 'padding-right');
			return (parseInt(padLeft) + parseInt(padRight));

		}

		function getStyleVal(elm, css) {
			return (window.getComputedStyle(elm, null).getPropertyValue(css))
		}
	};
</script>

<script type="text/javascript">
	$(document).ready(function () {
		$("form").submit(function () {

			$(this).submit(function () {
				return false;
			});
			return true;
		});
	});
</script>

<script>

	function addItemIade() {
		items_iade++;
		counter_iade.push(items_iade);
		var html_iade = "<tr>";
		html_iade += "<td>Numarası </td>";
		html_iade += "<td><input type='text' class='form-control' name='iadenumara[]' id='iadenumara" + items_iade + "'></td>";
		html_iade += "<td>Tarihi </td>";
		html_iade += "<td><input type='date' class='form-control' name='iadetarih[]' id='iadetarih" + items_iade + "' ></td>";
		html_iade += "<td><button type='button' class='btn btn-info btn-sm' onclick='addItemIade()'><i class='fa fa-plus'></i> Ekle</button> <button type='button' onclick='deleteRowIade(this);' class='btn btn-danger btn-sm' id='" + items_iade + "'><i class='fa fa-trash'></i> Sil</button> </td>";
		html_iade += "</tr>";

		var rowIade = document.getElementById("tbody_iade").insertRow();
		rowIade.innerHTML = html_iade;
		$("#iade_count").val(items_iade);

		// iade tarihi ileri tarih olmasın
		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth() + 1; //January is 0!
		var yyyy = today.getFullYear();

		if (dd < 10) {
			dd = '0' + dd;
		}

		if (mm < 10) {
			mm = '0' + mm;
		}

		today = yyyy + '-' + mm + '-' + dd;
		document.getElementById("iadetarih" + items_iade).setAttribute("max", today);
	}

	function deleteRowIade(button) {
		if (counter_iade.length >= 1) {
			counter_iade.pop();
		}
		if (counter_iade.length == 0) {
			counter_iade.push(1);
			toastr.warning("En az bir kayıt olması zorunludur, bu kayıt silinemez.");
		} else {
			var btnID = button.id;

			button.parentElement.parentElement.remove();
			var btnID = button.id;

			button.parentElement.parentElement.remove();
			$('#iadenumara' + btnID + '').remove();
			$('#iadetarih' + btnID + '').remove();
			items_iade--;

		}
		$("#iade_count").val(items_iade);
	}

	function deleteRowIndirim(button) {
		if (counter_indirim.length >= 1) {
			counter_indirim.pop();
		}
		if (counter_indirim.length == 0) {

			$('#genel_iskonto').attr('style', 'display:none;');
		}

		var btnID = button.id;

		button.parentElement.parentElement.remove();
		items_indirim--;
		$("#indirim_count").val(items_indirim);
		hesapla();

	}

	function deleteRowBanka(button) {
		if (counter_banka >= 1) {
			counter_banka.pop();
		}
		if (counter_banka == "0") {
			counter_banka.push(1);
			toastr.warning("En az bir kayıt olması zorunludur, bu kayıt silinemez.");
		} else {
			var btnID = button.id;

			button.parentElement.parentElement.remove();
			var btnID = button.id;

			button.parentElement.parentElement.remove();
			$('#ayarlar_bankaadi' + btnID + '').remove();
			$('#ayarlar_sube' + btnID + '').remove();
			$('#ayarlar_parabirimi' + btnID + '').remove();
			$('#ayarlar_hesapno' + btnID + '').remove();
			$('#ayarlar_iban' + btnID + '').remove();
			items_banka--;

		}
		$("#bankaCount").val(items_banka);
	}
</script>

<script>
	$(document).ready(function () {
		$('.ajaxIller').on('change', function (e) {
			var base_url = "<?php echo base_url();?>";
			var il_id = $(this).val();
			$.post(base_url + 'home/get_ilceler', {il_id: il_id}, function (result) {
				if (result && result.status != 'error') {
					var ilceler = result.data;
					var select = '<div class="ilceler"><div class="form-group"><label>İlçe</label><select id="ilce" name="cari_ilce" class="form-control select" required>';
					for (var i = 0; i < ilceler.length; i++) {
						select += '<option value="' + ilceler[i].id + '">' + ilceler[i].ilce + '</option>';
					}
					select += '</select></div></div>';
					$('div.ilceler').empty().html(select);
				} else {
					alert('Hata : ' + result.message);
				}
			});
		});
	});
</script>
<script>
	const stepList = document.querySelectorAll(".sbs > li");

	const checkElement = document.createElement("i");
	checkElement.classList.add("fa", "fa-check");

	const dotElement = document.createElement("i");
	dotElement.classList.add("fa", "fa-circle");

	function setFinished(element) {
		if (!element) return;
		element.classList.remove("active");
		if (!element.classList.contains("finished")) {
			element.classList.add("finished");
		}
		const indicator = element.querySelector(".indicator");
		if (indicator) {
			indicator.innerHTML = "";
			indicator.appendChild(checkElement.cloneNode(true));
		}
		setFinished(element.previousElementSibling);
	}

	function setDefault(element) {
		console.log(element);
		if (!element) return;
		element.classList.remove("active");
		element.classList.remove("finished");
		const indicator = element.querySelector(".indicator");
		if (indicator && indicator.dataset.default) {
			indicator.innerHTML = indicator.dataset.default;
		} else if (indicator) {
			indicator.innerHTML = "";
		}
		setDefault(element.nextElementSibling);
	}

	stepList.forEach((step) => {
		step.addEventListener("click", function (e) {
			e.preventDefault();
			if (this.classList.contains("active")) return;
			this.classList.add("active");
			this.classList.remove("finished");
			if (
				this.parentNode.classList.contains("sbs--border") ||
				this.parentNode.classList.contains("sbs--border-alt")
			) {
				const indicator = this.querySelector(".indicator");
				indicator.innerHTML = indicator.dataset.default;
			} else if (this.parentNode.classList.contains("sbs--circles")) {
				const indicator = this.querySelector(".indicator");
				indicator.innerHTML = "";
				indicator.appendChild(dotElement);
			} else if (this.parentNode.classList.contains("sbs--dots")) {
				const indicator = this.querySelector(".indicator");
				indicator.innerHTML = "";
			}
			setFinished(this.previousElementSibling);
			setDefault(this.nextElementSibling);
		});
	});


</script>

</body>
</html>
